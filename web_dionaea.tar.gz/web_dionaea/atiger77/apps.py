from django.apps import AppConfig


class Atiger77Config(AppConfig):
    name = 'atiger77'
